def receiveMsg():
    print('received a msg')