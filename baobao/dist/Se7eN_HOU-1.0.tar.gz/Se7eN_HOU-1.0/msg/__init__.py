__all__ = ['send', 'receive']
print("你导入的msg包%s" % ','.join(__all__))
def test():
    print("这里是msg包里面的test")