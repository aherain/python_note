def sendMsg():
    print('send a message')