from distutils.core import setup
setup(name = "Se7eN_HOU",version = "1.0",description = "Se7eN_HOU's module",author = "Se7eN_HOU",py_modules=["msg.receive","msg.send"])
